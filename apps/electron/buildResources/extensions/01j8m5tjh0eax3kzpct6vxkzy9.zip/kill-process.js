import { jsx as a, jsxs as f } from "/@preload/react-runtime.js";
import { _ as r, U as y, a as u, b as w } from "./@libs/$extension-api.js";
import { useState as d, useCallback as x, useEffect as N } from "/@preload/react.js";
function B(o, i = 2) {
  if (!+o) return "0 Bytes";
  const c = 1024, l = i < 0 ? 0 : i, p = [
    "Bytes",
    "KiB",
    "MiB",
    "GiB",
    "TiB",
    "PiB",
    "EiB",
    "ZiB",
    "YiB"
  ], n = Math.floor(Math.log(o) / Math.log(c));
  return `${parseFloat((o / Math.pow(c, n)).toFixed(l))} ${p[n]}`;
}
function k() {
  const [o, i] = d([]), [c, l] = d("loading");
  async function p(t) {
    try {
      const e = o.find(
        (s) => s.processName === t
      );
      if (!e) return;
      r.viewAction.sync.sendMessage(
        "process:kill",
        e.processName
      ), i(
        o.filter(
          (s) => s.processName !== e.processName
        )
      ), r.ui.showToast({
        title: `"${e.name}" process killed`
      });
    } catch (e) {
      r.ui.showToast({
        type: "error",
        title: "Something went wrong!",
        description: e.message
      });
    }
  }
  const n = x((t) => {
    const e = t ? r.ui.createToast({
      type: "loading",
      title: "Reloading..."
    }) : null;
    e == null || e.show(), r.viewAction.async.sendMessage("process:get-all").then((s) => {
      i((s == null ? void 0 : s.sort((h, g) => g.memory - h.memory)) ?? []), l("idle"), e == null || e.hide();
    }).catch((s) => {
      e == null || e.hide(), r.ui.showToast({
        type: "error",
        description: s.message,
        title: "Something when wrong!"
      }), l("error");
    });
  }, []), m = o.map((t) => ({
    icon: /* @__PURE__ */ a(
      y,
      {
        loading: "lazy",
        style: { height: "100%", width: "100%" },
        src: r.runtime.getFileIconURL(encodeURIComponent(t.path))
      }
    ),
    title: t.name,
    value: t.processName,
    subtitle: t.name === t.processName ? "" : t.processName,
    group: `Running processes (${o.length})`,
    actions: [
      {
        type: "button",
        value: "open-location",
        icon: u.FolderOpen,
        title: "Open file location",
        onAction() {
          r.shell.showItemInFolder(t.path);
        }
      },
      {
        type: "button",
        value: "reload",
        title: "Reload",
        icon: u.RotateCw,
        shortcut: { key: "r", mod1: "ctrlKey" },
        onAction() {
          n(!0);
        }
      }
    ],
    suffix: /* @__PURE__ */ f(
      "span",
      {
        className: "text-muted-foreground text-xs",
        style: { fontVariantNumeric: "tabular-nums" },
        children: [
          B(t.memory, 1),
          " ｜ ",
          t.cpu,
          "%"
        ]
      }
    )
  }));
  return N(() => {
    n();
  }, [n]), c === "error" ? /* @__PURE__ */ a("p", { className: "p-4 text-center text-destructive-text", children: "Error when fetching processes" }) : c === "loading" ? /* @__PURE__ */ a("p", { className: "p-4 text-center text-muted-foreground", children: "Fetching processes..." }) : /* @__PURE__ */ a("div", { className: "p-2", children: /* @__PURE__ */ a(w, { items: m, onItemSelected: p }) });
}
export {
  k as default
};
