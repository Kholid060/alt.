import { _ as n } from "./@libs/$extension-api.js";
import { exec as P } from "child_process";
async function c(t, a = !0) {
  const r = await new Promise((o, e) => {
    P(t, { shell: "powershell.exe" }, (s, i) => {
      s ? e(s) : o(i);
    });
  });
  return a ? JSON.parse(r) : r;
}
n.viewAction.async.on("process:get-all", async () => {
  const [t, a] = await Promise.all([
    c(
      "Get-WmiObject Win32_PerfFormattedData_PerfProc_Process | Where-Object { $_.name -inotmatch '_total|idle|svchost|taskhost' } | Select-Object -Property Name,PercentProcessorTime,WorkingSetPrivate | ConvertTo-Json"
    ),
    c(
      "Get-Process | Select-Object -Property ProcessName, Path, Product, MainWindowTitle | Where-Object {$_.ProcessName -inotmatch 'svchost|taskhost|wsmprovhost' -and $_.Path -ne $null} | ConvertTo-Json"
    )
  ]), r = a.reduce((o, e) => {
    if (!o[e.ProcessName]) {
      let s = e.MainWindowTitle || e.Product || e.ProcessName;
      s != null && s.includes("Windowsr Operating System") && (s = e.ProcessName), o[e.ProcessName] = {
        name: s,
        cpu: 0,
        memory: 0,
        path: e.Path,
        processName: e.ProcessName
      };
    }
    return o;
  }, {});
  return t.forEach((o) => {
    const e = o.Name.indexOf("#"), s = e === -1 ? o.Name : o.Name.slice(0, e);
    r[s] && (r[s].cpu += o.PercentProcessorTime, r[s].memory += o.WorkingSetPrivate);
  }), Object.values(r);
});
n.viewAction.sync.on("process:kill", (t) => {
  c(`Stop-Process -Name "${t}"`, !1);
});
