import { jsx as s } from "/@preload/react-runtime.js";
import { U as o, _ as n, a, b as p } from "./@libs/$extension-api.js";
import { useState as r, useEffect as c } from "/@preload/react.js";
function d(t) {
  return t.endsWith(".exe") || t.endsWith(".msc") ? "Application" : t.endsWith(".url") ? "Internet shortcut application" : "File";
}
function f() {
  const [t, i] = r([]), l = t.map((e) => ({
    title: e.name,
    value: e.appId,
    icon: /* @__PURE__ */ s(o, { src: n.shell.installedApps.getIconURL(e.appId) }),
    subtitle: d(e.path),
    actions: [
      {
        onAction() {
          n.shell.showItemInFolder(e.path);
        },
        type: "button",
        icon: a.FolderOpen,
        value: "open-folder",
        title: "Open containing folder",
        shortcut: { key: "e", mod1: "mod" }
      }
    ]
  }));
  return c(() => {
    n.shell.installedApps.query().then(i);
  }, []), /* @__PURE__ */ s("div", { className: "p-2", children: /* @__PURE__ */ s(
    p,
    {
      items: l,
      onItemSelected: (e) => {
        n.ui.closeWindow(), n.shell.installedApps.launch(e);
      }
    }
  ) });
}
export {
  f as default
};
