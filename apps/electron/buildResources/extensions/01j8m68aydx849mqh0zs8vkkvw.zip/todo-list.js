import { jsx as i } from "/@preload/react-runtime.js";
import { useRef as m, useState as p, useEffect as h } from "/@preload/react.js";
import { U as u, _ as r, a as f } from "./@libs/$extension-api.js";
function g(n) {
  let a = "";
  const s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", d = s.length;
  let l = 0;
  for (; l < n; )
    a += s.charAt(Math.floor(Math.random() * d)), l += 1;
  return a;
}
const c = "todos";
function y() {
  const n = m(""), [a, s] = p([]), d = a.map(
    (e) => ({
      value: e.id,
      title: e.title,
      group: e.isCompleted ? "Completed" : "To Do",
      icon: e.isCompleted ? /* @__PURE__ */ i(u.CheckCircle, {}) : /* @__PURE__ */ i(u.Circle, {}),
      actions: [
        {
          type: "button",
          title: "Delete",
          value: "delete",
          color: "destructive",
          icon: u.Trash2,
          shortcut: { mod1: "ctrlKey", key: "Delete" },
          onAction() {
            const t = a.filter(
              (o) => o.id !== e.id
            );
            s(t), r.storage.local.set(c, t);
          }
        }
      ],
      metadata: e.isCompleted ? 1 : 0
    })
  ).sort((e, t) => e.metadata - t.metadata);
  function l(e) {
    const t = a.map((o) => o.id !== e ? o : {
      ...o,
      isCompleted: !o.isCompleted
    });
    s(t), r.storage.local.set(c, t);
  }
  return h(() => {
    r.ui.searchPanel.clearValue(), r.ui.searchPanel.updatePlaceholder(
      "Search or press ctrl+enter to create to do"
    );
    const e = r.ui.searchPanel.onChanged.addListener(
      (t) => {
        n.current = t;
      }
    );
    return r.storage.local.get(c).then((t) => {
      s(t[c] ?? []);
    }), () => {
      e();
    };
  }, []), h(
    () => r.ui.searchPanel.onKeydown.addListener(
      async ({ ctrlKey: e, key: t }) => {
        if (!(!e || t !== "Enter"))
          try {
            const o = [
              ...a,
              {
                id: g(6),
                isCompleted: !1,
                title: n.current
              }
            ];
            s(o), await r.storage.local.set(c, o), r.ui.searchPanel.clearValue(), n.current = "";
          } catch (o) {
            r.ui.showToast({
              type: "error",
              description: o.message,
              title: "Error when adding to-do items"
            });
          }
      }
    ),
    [a]
  ), /* @__PURE__ */ i("div", { className: "p-2", children: /* @__PURE__ */ i(f, { items: d, onItemSelected: l }) });
}
export {
  y as default
};
