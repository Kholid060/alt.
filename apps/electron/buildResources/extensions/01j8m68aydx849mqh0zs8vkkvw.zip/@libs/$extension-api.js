var s = self.$UiIcons, e = self.$UiList, i = self._extension;
export {
  s as U,
  i as _,
  e as a
};
