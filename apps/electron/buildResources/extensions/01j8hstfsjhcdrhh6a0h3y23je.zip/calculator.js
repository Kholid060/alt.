import { jsxs as q, jsx as d } from "/@preload/react-runtime.js";
import { useRef as ee, useState as te, useEffect as oe } from "/@preload/react.js";
import { d as ne } from "./@libs/helper.js";
import { _ as M, U as F, a as G, b as L } from "./@libs/$extension-api.js";
function ae(n) {
  return n && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n;
}
var J = { exports: {} }, D = {}, W = {};
(function(n) {
  function e() {
    return e = Object.assign ? Object.assign.bind() : function(o) {
      for (var p = 1; p < arguments.length; p++) {
        var a = arguments[p];
        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (o[i] = a[i]);
      }
      return o;
    }, e.apply(this, arguments);
  }
  Object.defineProperty(n, "__esModule", { value: !0 });
  var t, r = { 0: 11, 1: 0, 2: 3, 3: 0, 4: 0, 5: 0, 6: 0, 7: 11, 8: 11, 9: 1, 10: 10, 11: 0, 12: 11, 13: 0, 14: -1 };
  n.tokenTypes = void 0, (t = n.tokenTypes || (n.tokenTypes = {}))[t.FUNCTION_WITH_ONE_ARG = 0] = "FUNCTION_WITH_ONE_ARG", t[t.NUMBER = 1] = "NUMBER", t[t.BINARY_OPERATOR_HIGH_PRECENDENCE = 2] = "BINARY_OPERATOR_HIGH_PRECENDENCE", t[t.CONSTANT = 3] = "CONSTANT", t[t.OPENING_PARENTHESIS = 4] = "OPENING_PARENTHESIS", t[t.CLOSING_PARENTHESIS = 5] = "CLOSING_PARENTHESIS", t[t.DECIMAL = 6] = "DECIMAL", t[t.POSTFIX_FUNCTION_WITH_ONE_ARG = 7] = "POSTFIX_FUNCTION_WITH_ONE_ARG", t[t.FUNCTION_WITH_N_ARGS = 8] = "FUNCTION_WITH_N_ARGS", t[t.BINARY_OPERATOR_LOW_PRECENDENCE = 9] = "BINARY_OPERATOR_LOW_PRECENDENCE", t[t.BINARY_OPERATOR_PERMUTATION = 10] = "BINARY_OPERATOR_PERMUTATION", t[t.COMMA = 11] = "COMMA", t[t.EVALUATED_FUNCTION = 12] = "EVALUATED_FUNCTION", t[t.EVALUATED_FUNCTION_PARAMETER = 13] = "EVALUATED_FUNCTION_PARAMETER", t[t.SPACE = 14] = "SPACE", n.createTokens = function(o) {
    return [{ token: "sin", show: "sin", type: 0, value: o.math.sin }, { token: "cos", show: "cos", type: 0, value: o.math.cos }, { token: "tan", show: "tan", type: 0, value: o.math.tan }, { token: "pi", show: "&pi;", type: 3, value: "PI" }, { token: "(", show: "(", type: 4, value: "(" }, { token: ")", show: ")", type: 5, value: ")" }, { token: "P", show: "P", type: 10, value: o.math.P }, { token: "C", show: "C", type: 10, value: o.math.C }, { token: " ", show: " ", type: 14, value: " ".anchor }, { token: "asin", show: "asin", type: 0, value: o.math.asin }, { token: "acos", show: "acos", type: 0, value: o.math.acos }, { token: "atan", show: "atan", type: 0, value: o.math.atan }, { token: "7", show: "7", type: 1, value: "7" }, { token: "8", show: "8", type: 1, value: "8" }, { token: "9", show: "9", type: 1, value: "9" }, { token: "int", show: "Int", type: 0, value: Math.floor }, { token: "cosh", show: "cosh", type: 0, value: o.math.cosh }, { token: "acosh", show: "acosh", type: 0, value: o.math.acosh }, { token: "ln", show: " ln", type: 0, value: Math.log }, { token: "^", show: "^", type: 10, value: Math.pow }, { token: "root", show: "root", type: 0, value: Math.sqrt }, { token: "4", show: "4", type: 1, value: "4" }, { token: "5", show: "5", type: 1, value: "5" }, { token: "6", show: "6", type: 1, value: "6" }, { token: "/", show: "&divide;", type: 2, value: o.math.div }, { token: "!", show: "!", type: 7, value: o.math.fact }, { token: "tanh", show: "tanh", type: 0, value: o.math.tanh }, { token: "atanh", show: "atanh", type: 0, value: o.math.atanh }, { token: "Mod", show: " Mod ", type: 2, value: o.math.mod }, { token: "1", show: "1", type: 1, value: "1" }, { token: "2", show: "2", type: 1, value: "2" }, { token: "3", show: "3", type: 1, value: "3" }, { token: "*", show: "&times;", type: 2, value: o.math.mul }, { token: "sinh", show: "sinh", type: 0, value: o.math.sinh }, { token: "asinh", show: "asinh", type: 0, value: o.math.asinh }, { token: "e", show: "e", type: 3, value: "E" }, { token: "log", show: " log", type: 0, value: o.math.log }, { token: "0", show: "0", type: 1, value: "0" }, { token: ".", show: ".", type: 6, value: "." }, { token: "+", show: "+", type: 9, value: o.math.add }, { token: "-", show: "-", type: 9, value: o.math.sub }, { token: ",", show: ",", type: 11, value: "," }, { token: "Sigma", show: "&Sigma;", type: 12, value: o.math.sigma }, { token: "n", show: "n", type: 13, value: "n" }, { token: "Pi", show: "&Pi;", type: 12, value: o.math.Pi }, { token: "pow", show: "pow", type: 8, value: Math.pow, numberOfArguments: 2 }, { token: "&", show: "&", type: 9, value: o.math.and }].map(function(p) {
      return e({}, p, { precedence: r[p.type] });
    });
  }, n.preced = r;
})(W);
Object.defineProperty(D, "__esModule", { value: !0 });
var h = W;
function v(n, e) {
  for (var t = 0; t < n.length; t++) n[t] += e;
  return n;
}
var I = { 0: !0, 1: !0, 3: !0, 4: !0, 6: !0, 8: !0, 9: !0, 12: !0, 13: !0, 14: !0 }, m = { 0: !0, 1: !0, 2: !0, 3: !0, 4: !0, 5: !0, 6: !0, 7: !0, 8: !0, 9: !0, 10: !0, 11: !0, 12: !0, 13: !0 }, re = { 0: !0, 3: !0, 4: !0, 8: !0, 12: !0, 13: !0 }, A = {}, U = { 0: !0, 1: !0, 3: !0, 4: !0, 6: !0, 8: !0, 12: !0, 13: !0 }, se = { 1: !0 }, E = [[], ["1", "2", "3", "7", "8", "9", "4", "5", "6", "+", "-", "*", "/", "(", ")", "^", "!", "P", "C", "e", "0", ".", ",", "n", " ", "&"], ["pi", "ln", "Pi"], ["sin", "cos", "tan", "Del", "int", "Mod", "log", "pow"], ["asin", "acos", "atan", "cosh", "root", "tanh", "sinh"], ["acosh", "atanh", "asinh", "Sigma"]];
function he(n, e, t, r) {
  for (var o = 0; o < r; o++) if (n[t + o] !== e[o]) return !1;
  return !0;
}
function K(n, e) {
  for (var t = 0; t < e.length; t++) if (e[t].token === n) return t;
  return -1;
}
D.addToken = function(n) {
  for (var e = 0; e < n.length; e++) {
    var t = n[e].token.length, r = -1;
    n[e].type === h.tokenTypes.FUNCTION_WITH_N_ARGS && n[e].numberOfArguments === void 0 && (n[e].numberOfArguments = 2), E[t] = E[t] || [];
    for (var o = 0; o < E[t].length; o++) if (n[e].token === E[t][o]) {
      r = K(E[t][o], this.tokens);
      break;
    }
    r === -1 ? (this.tokens.push(n[e]), n[e].precedence = h.preced[n[e].type], E.length <= n[e].token.length && (E[n[e].token.length] = []), E[n[e].token.length].push(n[e].token)) : (this.tokens[r] = n[e], n[e].precedence = h.preced[n[e].type]);
  }
}, D.lex = function(n, e) {
  var t, r = { value: this.math.changeSign, type: h.tokenTypes.FUNCTION_WITH_ONE_ARG, precedence: 4, show: "-" }, o = { value: ")", show: ")", type: h.tokenTypes.CLOSING_PARENTHESIS, precedence: 0 }, p = { value: "(", type: h.tokenTypes.OPENING_PARENTHESIS, precedence: 0, show: "(" }, a = [p], i = [], s = n, u = I, N = 0, l = A, k = "";
  e !== void 0 && this.addToken(e);
  var T = function(V, w) {
    for (var S, O, P, $ = [], X = w.length, R = 0; R < X; R++) if (!(R < X - 1 && w[R] === " " && w[R + 1] === " ")) {
      for (S = "", O = w.length - R > E.length - 2 ? E.length - 1 : w.length - R; O > 0; O--) if (E[O] !== void 0) for (P = 0; P < E[O].length; P++) he(w, E[O][P], R, O) && (S = E[O][P], P = E[O].length, O = 0);
      if (R += S.length - 1, S === "") throw new Error("Can't understand after " + w.slice(R));
      $.push(V.tokens[K(S, V.tokens)]);
    }
    return $;
  }(this, s);
  for (t = 0; t < T.length; t++) {
    var _ = T[t];
    if (_.type !== 14) {
      var g, b = _.token, c = _.type, C = _.value, j = _.precedence, x = _.show, y = a[a.length - 1];
      for (g = i.length; g-- && i[g] === 0; ) if ([h.tokenTypes.FUNCTION_WITH_ONE_ARG, h.tokenTypes.BINARY_OPERATOR_HIGH_PRECENDENCE, h.tokenTypes.CONSTANT, h.tokenTypes.OPENING_PARENTHESIS, h.tokenTypes.CLOSING_PARENTHESIS, h.tokenTypes.BINARY_OPERATOR_LOW_PRECENDENCE, h.tokenTypes.BINARY_OPERATOR_PERMUTATION, h.tokenTypes.COMMA, h.tokenTypes.EVALUATED_FUNCTION, h.tokenTypes.EVALUATED_FUNCTION_PARAMETER].indexOf(c) !== -1) {
        if (u[c] !== !0) throw new Error(b + " is not allowed after " + k);
        a.push(o), u = m, l = U, i.pop();
      }
      if (u[c] !== !0) throw new Error(b + " is not allowed after " + k);
      l[c] === !0 && (c = h.tokenTypes.BINARY_OPERATOR_HIGH_PRECENDENCE, C = this.math.mul, x = "&times;", j = 3, t -= 1);
      var f = { value: C, type: c, precedence: j, show: x, numberOfArguments: _.numberOfArguments };
      if (c === h.tokenTypes.FUNCTION_WITH_ONE_ARG) u = I, l = A, v(i, 2), a.push(f), T[t + 1].type !== h.tokenTypes.OPENING_PARENTHESIS && (a.push(p), i.push(2));
      else if (c === h.tokenTypes.NUMBER) y.type === h.tokenTypes.NUMBER ? (y.value += C, v(i, 1)) : a.push(f), u = m, l = re;
      else if (c === h.tokenTypes.BINARY_OPERATOR_HIGH_PRECENDENCE) u = I, l = A, v(i, 2), a.push(f);
      else if (c === h.tokenTypes.CONSTANT) a.push(f), u = m, l = U;
      else if (c === h.tokenTypes.OPENING_PARENTHESIS) v(i, 1), N++, u = I, l = A, a.push(f);
      else if (c === h.tokenTypes.CLOSING_PARENTHESIS) {
        if (!N) throw new Error("Closing parenthesis are more than opening one, wait What!!!");
        N--, u = m, l = U, a.push(f), v(i, 1);
      } else if (c === h.tokenTypes.DECIMAL) {
        if (y.hasDec) throw new Error("Two decimals are not allowed in one number");
        y.type !== h.tokenTypes.NUMBER && (y = { show: "0", value: 0, type: h.tokenTypes.NUMBER, precedence: 0 }, a.push(y)), u = se, v(i, 1), l = A, y.value += C, y.hasDec = !0;
      } else c === h.tokenTypes.POSTFIX_FUNCTION_WITH_ONE_ARG && (u = m, l = U, v(i, 1), a.push(f));
      c === h.tokenTypes.FUNCTION_WITH_N_ARGS ? (u = I, l = A, v(i, _.numberOfArguments + 2), a.push(f), T[t + 1].type !== h.tokenTypes.OPENING_PARENTHESIS && (a.push(p), i.push(_.numberOfArguments + 2))) : c === h.tokenTypes.BINARY_OPERATOR_LOW_PRECENDENCE ? (y.type === h.tokenTypes.BINARY_OPERATOR_LOW_PRECENDENCE ? y.value === this.math.add ? (y.value = C, y.show = x, v(i, 1)) : y.value === this.math.sub && x === "-" && (y.value = this.math.add, y.show = "+", v(i, 1)) : y.type !== h.tokenTypes.CLOSING_PARENTHESIS && y.type !== h.tokenTypes.POSTFIX_FUNCTION_WITH_ONE_ARG && y.type !== h.tokenTypes.NUMBER && y.type !== h.tokenTypes.CONSTANT && y.type !== h.tokenTypes.EVALUATED_FUNCTION_PARAMETER ? b === "-" && (u = I, l = A, v(i, 1).push(2), a.push(r), a.push(p)) : (a.push(f), v(i, 2)), u = I, l = A) : c === h.tokenTypes.BINARY_OPERATOR_PERMUTATION ? (u = I, l = A, v(i, 2), a.push(f)) : c === h.tokenTypes.COMMA ? (u = I, l = A, a.push(f)) : c === h.tokenTypes.EVALUATED_FUNCTION ? (u = I, l = A, v(i, 6), a.push(f), T[t + 1].type !== h.tokenTypes.OPENING_PARENTHESIS && (a.push(p), i.push(6))) : c === h.tokenTypes.EVALUATED_FUNCTION_PARAMETER && (u = m, l = U, a.push(f)), v(i, -1), k = b;
    } else if (t > 0 && t < T.length - 1 && T[t + 1].type === 1 && (T[t - 1].type === 1 || T[t - 1].type === 6)) throw new Error("Unexpected Space");
  }
  for (g = i.length; g--; ) a.push(o);
  if (u[5] !== !0) throw new Error("complete the expression");
  for (; N--; ) a.push(o);
  return a.push(o), a;
};
var Q = {};
(function(n) {
  Object.defineProperty(n, "__esModule", { value: !0 }), n.toPostfix = function(e) {
    for (var t, r, o, p = [], a = -1, i = -1, s = [{ value: "(", type: 4, precedence: 0, show: "(" }], u = 1; u < e.length; u++) if (e[u].type === 1 || e[u].type === 3 || e[u].type === 13) e[u].type === 1 && (e[u].value = Number(e[u].value)), p.push(e[u]);
    else if (e[u].type === 4) s.push(e[u]);
    else if (e[u].type === 5) for (; ((N = r = s.pop()) == null ? void 0 : N.type) !== 4; ) {
      var N;
      r && p.push(r);
    }
    else if (e[u].type === 11) {
      for (; ((l = r = s.pop()) == null ? void 0 : l.type) !== 4; ) {
        var l;
        r && p.push(r);
      }
      s.push(r);
    } else {
      i = (t = e[u]).precedence, a = (o = s[s.length - 1]).precedence;
      var k = o.value == "Math.pow" && t.value == "Math.pow";
      if (i > a) s.push(t);
      else {
        for (; a >= i && !k || k && i < a; ) r = s.pop(), o = s[s.length - 1], r && p.push(r), a = o.precedence, k = t.value == "Math.pow" && o.value == "Math.pow";
        s.push(t);
      }
    }
    return p;
  };
})(Q);
var Z = {};
(function(n) {
  Object.defineProperty(n, "__esModule", { value: !0 }), n.postfixEval = function(e, t) {
    (t = t || {}).PI = Math.PI, t.E = Math.E;
    for (var r, o, p, a = [], i = t.n !== void 0, s = 0; s < e.length; s++) if (e[s].type === 1) a.push({ value: e[s].value, type: 1 });
    else if (e[s].type === 3) a.push({ value: t[e[s].value], type: 1 });
    else if (e[s].type === 0) {
      var u = a[a.length - 1];
      Array.isArray(u) ? u.push(e[s]) : u.value = e[s].value(u.value);
    } else if (e[s].type === 7) {
      var N = a[a.length - 1];
      Array.isArray(N) ? N.push(e[s]) : N.value = e[s].value(N.value);
    } else if (e[s].type === 8) {
      for (var l = [], k = 0; k < e[s].numberOfArguments; k++) {
        var T = a.pop();
        T && l.push(T.value);
      }
      a.push({ type: 1, value: e[s].value.apply(e[s], l.reverse()) });
    } else if (e[s].type === 10) r = a.pop(), o = a.pop(), Array.isArray(o) ? ((o = o.concat(r)).push(e[s]), a.push(o)) : Array.isArray(r) ? (r.unshift(o), r.push(e[s]), a.push(r)) : a.push({ type: 1, value: e[s].value(o.value, r.value) });
    else if (e[s].type === 2 || e[s].type === 9) r = a.pop(), o = a.pop(), Array.isArray(o) ? ((o = o.concat(r)).push(e[s]), a.push(o)) : Array.isArray(r) ? (r.unshift(o), r.push(e[s]), a.push(r)) : a.push({ type: 1, value: e[s].value(o.value, r.value) });
    else if (e[s].type === 12) {
      r = a.pop();
      var _ = void 0;
      _ = !Array.isArray(r) && r ? [r] : r || [], o = a.pop(), p = a.pop(), a.push({ type: 1, value: e[s].value(p.value, o.value, _) });
    } else e[s].type === 13 && (i ? a.push({ value: t[e[s].value], type: 3 }) : a.push([e[s]]));
    if (a.length > 1) throw new Error("Uncaught Syntax error");
    return parseFloat(a[0].value.toFixed(15));
  };
})(Z);
var Y = {};
Object.defineProperty(Y, "__esModule", { value: !0 });
Y.createMathFunctions = function(n) {
  return { isDegree: !0, acos: function(e) {
    return n.math.isDegree ? 180 / Math.PI * Math.acos(e) : Math.acos(e);
  }, add: function(e, t) {
    return e + t;
  }, asin: function(e) {
    return n.math.isDegree ? 180 / Math.PI * Math.asin(e) : Math.asin(e);
  }, atan: function(e) {
    return n.math.isDegree ? 180 / Math.PI * Math.atan(e) : Math.atan(e);
  }, acosh: function(e) {
    return Math.log(e + Math.sqrt(e * e - 1));
  }, asinh: function(e) {
    return Math.log(e + Math.sqrt(e * e + 1));
  }, atanh: function(e) {
    return Math.log((1 + e) / (1 - e));
  }, C: function(e, t) {
    var r = 1, o = e - t, p = t;
    p < o && (p = o, o = t);
    for (var a = p + 1; a <= e; a++) r *= a;
    var i = n.math.fact(o);
    return i === "NaN" ? "NaN" : r / i;
  }, changeSign: function(e) {
    return -e;
  }, cos: function(e) {
    return n.math.isDegree && (e = n.math.toRadian(e)), Math.cos(e);
  }, cosh: function(e) {
    return (Math.pow(Math.E, e) + Math.pow(Math.E, -1 * e)) / 2;
  }, div: function(e, t) {
    return e / t;
  }, fact: function(e) {
    if (e % 1 != 0) return "NaN";
    for (var t = 1, r = 2; r <= e; r++) t *= r;
    return t;
  }, inverse: function(e) {
    return 1 / e;
  }, log: function(e) {
    return Math.log(e) / Math.log(10);
  }, mod: function(e, t) {
    return e % t;
  }, mul: function(e, t) {
    return e * t;
  }, P: function(e, t) {
    for (var r = 1, o = Math.floor(e) - Math.floor(t) + 1; o <= Math.floor(e); o++) r *= o;
    return r;
  }, Pi: function(e, t, r) {
    for (var o = 1, p = e; p <= t; p++) o *= Number(n.postfixEval(r, { n: p }));
    return o;
  }, pow10x: function(e) {
    for (var t = 1; e--; ) t *= 10;
    return t;
  }, sigma: function(e, t, r) {
    for (var o = 0, p = e; p <= t; p++) o += Number(n.postfixEval(r, { n: p }));
    return o;
  }, sin: function(e) {
    return n.math.isDegree && (e = n.math.toRadian(e)), Math.sin(e);
  }, sinh: function(e) {
    return (Math.pow(Math.E, e) - Math.pow(Math.E, -1 * e)) / 2;
  }, sub: function(e, t) {
    return e - t;
  }, tan: function(e) {
    return n.math.isDegree && (e = n.math.toRadian(e)), Math.tan(e);
  }, tanh: function(e) {
    return n.math.sinh(e) / n.math.cosh(e);
  }, toRadian: function(e) {
    return e * Math.PI / 180;
  }, and: function(e, t) {
    return e & t;
  } };
};
var z = D, B = W, ue = Q, pe = Z, ie = Y, H = function() {
  function n() {
    this.toPostfix = ue.toPostfix, this.addToken = z.addToken, this.lex = z.lex, this.postfixEval = pe.postfixEval, this.math = ie.createMathFunctions(this), this.tokens = B.createTokens(this);
  }
  return n.prototype.eval = function(e, t, r) {
    return this.postfixEval(this.toPostfix(this.lex(e, t)), r);
  }, n;
}();
H.TOKEN_TYPES = B.tokenTypes, H.tokenTypes = B.tokenTypes, J.exports = H;
var le = J.exports;
const ce = /* @__PURE__ */ ae(le), ye = new ce();
M.ui.searchPanel.updatePlaceholder("Math expression...");
function Te() {
  const n = ee(!0), [e, t] = te({
    value: "",
    isError: !1
  });
  if (oe(
    () => M.ui.searchPanel.onChanged.addListener(
      ne((o) => {
        if (!o.trim()) {
          n.current = !0, t({ isError: !1, value: "" });
          return;
        }
        n.current = !1;
        try {
          t({
            isError: !1,
            value: ye.eval(o, []).toString()
          });
        } catch (p) {
          p instanceof Error && t({ isError: !0, value: p.message });
        }
      }, 500)
    ),
    []
  ), e.isError)
    return /* @__PURE__ */ q("div", { className: "py-4 px-6", children: [
      /* @__PURE__ */ d(F, { color: "destructive", children: "Invalid Math Expression:" }),
      /* @__PURE__ */ d("div", { className: "bg-card rounded-md p-2", style: { minHeight: "6rem" }, children: /* @__PURE__ */ d(F, { variant: "code", color: "muted", children: e.value }) })
    ] });
  if (!e.value && n.current)
    return /* @__PURE__ */ q("div", { className: "px-6 py-4 text-center", children: [
      /* @__PURE__ */ d("p", { children: "Write Math expression" }),
      /* @__PURE__ */ d(F, { color: "muted", variant: "body-small", children: "For example: 2*25/10" })
    ] });
  const r = [
    {
      icon: /* @__PURE__ */ d(G.Icon, { icon: L.Calculator }),
      title: e.value,
      value: "result",
      onSelected() {
        M.clipboard.write("text", e.value).then(() => {
          M.ui.showToast({
            title: "Copied to clipboard"
          });
        });
      },
      description: "Copy to clipboard",
      actions: [
        {
          type: "button",
          value: "paste",
          title: "Paste result",
          icon: L.Clipboard,
          onAction() {
            M.clipboard.paste(e.value);
          }
        }
      ]
    },
    {
      title: "See Supported Symbols",
      onSelected() {
        M.shell.openURL(
          "https://github.com/bugwheels94/math-expression-evaluator/?tab=readme-ov-file#supported-symbols"
        );
      },
      icon: /* @__PURE__ */ d(G.Icon, { icon: L.Link }),
      value: "symbols"
    }
  ];
  return /* @__PURE__ */ d("div", { className: "p-2", children: /* @__PURE__ */ d(G, { shouldFilter: !1, items: r }) });
}
export {
  Te as default
};
